1. unzip and put all source files in one folder.
2. type "make" to compile
3. type "./mutex <cs_int> <next_req> <total_exec_time> <option>" to run!
